package GLPI::Agent::Task::NetInventory::Version;

use strict;
use warnings;

use constant VERSION => "6.4";

1;
