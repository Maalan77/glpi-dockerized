package GLPI::Agent::Task::NetDiscovery::Version;

use strict;
use warnings;

use constant VERSION => "6.4";

1;
